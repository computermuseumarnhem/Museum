Discovered this demonstration port of Concurrent CP/M-86 to the IBM Displaywriter

While doing one of my regular trawls through the Internet for any references to Displaywriter I happened across an oblique reference to some unknown DRI format diskettes that were part of a recovery from DRI. I poked about in the images and to my surprise and delight it was CP/M-86. We've long known that a version of CP/M-86 was listed for the Displaywriter but we had never seen it rediscovered.

The two diskette images here appear to be a demonstration port of the multi-user version of CP/M-86 known as Concurrent CP/M-86. It appears to have been done around October 1982 and at that time MP/M-86 and CCP/M-86 were under active (parallel?) development.

I imaged the diskettes onto DW Media and it boots fine and the limited commands included seem to work ok, there are some screenshots here showing it in action.

nw@retroComputingTasmania.com January 2016
